<?php
if ($config["modulAction"] == "list") {$viewItem['recipe_x_insertWhen']=1;}
?>