<?php
if ($config["modulAction"] == "list") {$viewItem['video_x_insertWhen']=1;}
?>