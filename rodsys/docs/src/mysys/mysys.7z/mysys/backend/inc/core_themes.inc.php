<?php
if (!DEFINED('runOK')) exit;
$viewItem = viewConfig($config,$viewItem);
?>