<?php
$viewItem[$config["modulSelect"].'_x_insertWhen']=0;
?>