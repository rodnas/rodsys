<?php
if (!DEFINED('runOK')) exit;
$viewItem[$config["modulSelect"]."_x_description"]=0;
$viewItem = viewConfig($config,$viewItem);
?>