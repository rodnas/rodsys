<?php
if ($config["modulAction"] == "list")
	{
	if ($config[$config["modulSelect"]]["viewDescription"]==1) {$viewItem['recipetopic_x_description']=1;} else {$viewItem['recipetopic_x_description']=0;}
	}
?>