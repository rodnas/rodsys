// We need to actually use the code manually here as this is tricky do in
// themes at present.
YUI().use('moodle-theme_bootstrap-bootstrap', function(Y) {
    Y.Moodle.theme_bootstrap.bootstrap.init();
});
