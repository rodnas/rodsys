<?php
		       $plugin->version = 2012040500;
               $plugin->requires = 2011070100;
		       $plugin->maturity  = MATURITY_STABLE;
		       $plugin->release = '2.x (Build: 2012040500)';
		       ?>
		    