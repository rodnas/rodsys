Course overview (legacy) block for Moodle
=========================================

This is a legacy version of the standard Course overview block which used to be
part of the standard Moodle installation. Starting with Moodle 3.3, the block
has been moved to the plugins directory and can be installed as an additional
plugin.

See <https://moodle.org/plugins/block_course_overview> for more details.
