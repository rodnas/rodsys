atto_fullscreen
=================

This is a plugin for Atto editor in Moodle that allows it to toggle into
fullscreen mode. To install unpack to lib/editor/atto/plugins/fullscreen, 
and visit the admin notifications page to install.  Then add the button
on the Atto toolbar settings page (maybe next to html).

All original files are copyright Daniel Thies 2014 dthies@ccal.edu
and are licensed under the included GPL 3.
